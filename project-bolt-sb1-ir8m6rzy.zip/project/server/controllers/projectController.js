import Project from '../models/projectModel.js';
import Task from '../models/taskModel.js';

// @desc    Create new project
// @route   POST /api/projects
// @access  Private
const createProject = async (req, res) => {
  try {
    const { title, description } = req.body;

    // Check if user already has 4 projects
    const projectCount = await Project.countDocuments({ user: req.user._id });
    if (projectCount >= 4) {
      res.status(400).json({ message: 'Maximum number of projects (4) reached' });
      return;
    }

    const project = await Project.create({
      title,
      description,
      user: req.user._id,
    });

    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all user projects
// @route   GET /api/projects
// @access  Private
const getProjects = async (req, res) => {
  try {
    const projects = await Project.find({ user: req.user._id });
    res.json(projects);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get project by ID
// @route   GET /api/projects/:id
// @access  Private
const getProjectById = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      res.status(404).json({ message: 'Project not found' });
      return;
    }

    // Check if the project belongs to the user
    if (project.user.toString() !== req.user._id.toString()) {
      res.status(401).json({ message: 'Not authorized to access this project' });
      return;
    }

    res.json(project);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update project
// @route   PUT /api/projects/:id
// @access  Private
const updateProject = async (req, res) => {
  try {
    const { title, description } = req.body;
    const project = await Project.findById(req.params.id);

    if (!project) {
      res.status(404).json({ message: 'Project not found' });
      return;
    }

    // Check if the project belongs to the user
    if (project.user.toString() !== req.user._id.toString()) {
      res.status(401).json({ message: 'Not authorized to update this project' });
      return;
    }

    project.title = title || project.title;
    project.description = description || project.description;

    const updatedProject = await project.save();
    res.json(updatedProject);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete project
// @route   DELETE /api/projects/:id
// @access  Private
const deleteProject = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      res.status(404).json({ message: 'Project not found' });
      return;
    }

    // Check if the project belongs to the user
    if (project.user.toString() !== req.user._id.toString()) {
      res.status(401).json({ message: 'Not authorized to delete this project' });
      return;
    }

    // Delete all tasks associated with the project
    await Task.deleteMany({ project: req.params.id });
    
    // Delete the project
    await project.remove();
    
    res.json({ message: 'Project and associated tasks removed' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export { createProject, getProjects, getProjectById, updateProject, deleteProject };