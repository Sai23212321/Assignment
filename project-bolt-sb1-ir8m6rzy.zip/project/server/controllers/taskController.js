import Task from '../models/taskModel.js';
import Project from '../models/projectModel.js';

// @desc    Create new task
// @route   POST /api/tasks
// @access  Private
const createTask = async (req, res) => {
  try {
    const { title, description, status, projectId } = req.body;

    // Check if project exists and belongs to user
    const project = await Project.findById(projectId);
    if (!project) {
      res.status(404).json({ message: 'Project not found' });
      return;
    }

    if (project.user.toString() !== req.user._id.toString()) {
      res.status(401).json({ message: 'Not authorized to add tasks to this project' });
      return;
    }

    const task = await Task.create({
      title,
      description,
      status,
      project: projectId,
      user: req.user._id,
      completedAt: status === 'Completed' ? new Date() : null,
    });

    res.status(201).json(task);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get tasks by project
// @route   GET /api/tasks/project/:projectId
// @access  Private
const getTasksByProject = async (req, res) => {
  try {
    const projectId = req.params.projectId;
    
    // Check if project exists and belongs to user
    const project = await Project.findById(projectId);
    if (!project) {
      res.status(404).json({ message: 'Project not found' });
      return;
    }

    if (project.user.toString() !== req.user._id.toString()) {
      res.status(401).json({ message: 'Not authorized to view tasks from this project' });
      return;
    }

    const tasks = await Task.find({ project: projectId }).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get task by ID
// @route   GET /api/tasks/:id
// @access  Private
const getTaskById = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      res.status(404).json({ message: 'Task not found' });
      return;
    }

    // Check if the task belongs to the user
    if (task.user.toString() !== req.user._id.toString()) {
      res.status(401).json({ message: 'Not authorized to access this task' });
      return;
    }

    res.json(task);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update task
// @route   PUT /api/tasks/:id
// @access  Private
const updateTask = async (req, res) => {
  try {
    const { title, description, status } = req.body;
    const task = await Task.findById(req.params.id);

    if (!task) {
      res.status(404).json({ message: 'Task not found' });
      return;
    }

    // Check if the task belongs to the user
    if (task.user.toString() !== req.user._id.toString()) {
      res.status(401).json({ message: 'Not authorized to update this task' });
      return;
    }

    task.title = title || task.title;
    task.description = description || task.description;
    
    // Set completion date if status changed to Completed
    if (status === 'Completed' && task.status !== 'Completed') {
      task.completedAt = new Date();
    } else if (status !== 'Completed') {
      task.completedAt = null;
    }
    
    task.status = status || task.status;

    const updatedTask = await task.save();
    res.json(updatedTask);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete task
// @route   DELETE /api/tasks/:id
// @access  Private
const deleteTask = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      res.status(404).json({ message: 'Task not found' });
      return;
    }

    // Check if the task belongs to the user
    if (task.user.toString() !== req.user._id.toString()) {
      res.status(401).json({ message: 'Not authorized to delete this task' });
      return;
    }

    await task.deleteOne();
    res.json({ message: 'Task removed' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export { createTask, getTasksByProject, getTaskById, updateTask, deleteTask };