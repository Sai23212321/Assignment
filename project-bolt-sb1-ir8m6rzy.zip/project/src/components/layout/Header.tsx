import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, User, Menu } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Header: React.FC = () => {
  const { state, logout } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="bg-indigo-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold">TaskTracker</Link>
          
          <div className="hidden md:flex items-center space-x-4">
            {state.user ? (
              <>
                <Link to="/dashboard" className="hover:text-indigo-200 transition-colors">
                  Dashboard
                </Link>
                <Link to="/projects" className="hover:text-indigo-200 transition-colors">
                  Projects
                </Link>
                <div className="relative group">
                  <button className="flex items-center space-x-1 hover:text-indigo-200 transition-colors">
                    <span>{state.user.name}</span>
                    <User size={16} />
                  </button>
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-xl z-20 invisible group-hover:visible transition-all duration-300 transform opacity-0 group-hover:opacity-100">
                    <Link to="/profile" className="block px-4 py-2 text-gray-800 hover:bg-indigo-100 rounded-t-md">
                      Profile
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-4 py-2 text-gray-800 hover:bg-indigo-100 rounded-b-md flex items-center"
                    >
                      <LogOut size={16} className="mr-2" /> Logout
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <>
                <Link to="/login" className="hover:text-indigo-200 transition-colors">
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-white text-indigo-600 px-4 py-2 rounded-md hover:bg-indigo-100 transition-colors"
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>
          
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white focus:outline-none"
            >
              <Menu size={24} />
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-2">
            {state.user ? (
              <div className="flex flex-col space-y-2">
                <Link to="/dashboard" className="hover:text-indigo-200 transition-colors py-2">
                  Dashboard
                </Link>
                <Link to="/projects" className="hover:text-indigo-200 transition-colors py-2">
                  Projects
                </Link>
                <Link to="/profile" className="hover:text-indigo-200 transition-colors py-2">
                  Profile
                </Link>
                <button
                  onClick={handleLogout}
                  className="text-left hover:text-indigo-200 transition-colors py-2 flex items-center"
                >
                  <LogOut size={16} className="mr-2" /> Logout
                </button>
              </div>
            ) : (
              <div className="flex flex-col space-y-2">
                <Link to="/login" className="hover:text-indigo-200 transition-colors py-2">
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-white text-indigo-600 px-4 py-2 rounded-md hover:bg-indigo-100 transition-colors inline-block w-max"
                >
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;