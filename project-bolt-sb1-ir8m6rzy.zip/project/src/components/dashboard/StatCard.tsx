import React from 'react';

interface StatCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  color: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, color }) => {
  const getColorClasses = () => {
    switch (color) {
      case 'indigo':
        return 'bg-indigo-50 text-indigo-500 border-indigo-200';
      case 'emerald':
        return 'bg-emerald-50 text-emerald-500 border-emerald-200';
      case 'amber':
        return 'bg-amber-50 text-amber-500 border-amber-200';
      case 'red':
        return 'bg-red-50 text-red-500 border-red-200';
      default:
        return 'bg-gray-50 text-gray-500 border-gray-200';
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-5 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-medium text-gray-500">{title}</h3>
          <p className="text-3xl font-semibold mt-1">{value}</p>
        </div>
        <div className={`p-3 rounded-full ${getColorClasses()}`}>{icon}</div>
      </div>
    </div>
  );
};

export default StatCard;