import React, { useEffect, useState } from 'react';
import { useTask } from '../../context/TaskContext';
import { CheckCircle, Circle, Clock, MoreVertical, Edit, Trash2 } from 'lucide-react';
import Button from '../ui/Button';
import { Task } from '../../types';
import { format } from 'date-fns';

interface TaskListProps {
  projectId: string;
  onAddTask: () => void;
  onEditTask: (task: Task) => void;
}

const TaskList: React.FC<TaskListProps> = ({ projectId, onAddTask, onEditTask }) => {
  const { state, getTasksByProject, updateTask, deleteTask } = useTask();
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    getTasksByProject(projectId);
  }, [projectId]);

  const handleStatusChange = async (taskId: string, newStatus: 'To Do' | 'In Progress' | 'Completed') => {
    const task = state.tasks.find((t) => t._id === taskId);
    if (task) {
      await updateTask(taskId, task.title, task.description, newStatus);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      await deleteTask(taskId);
    }
    setActiveDropdown(null);
  };

  const toggleDropdown = (taskId: string) => {
    setActiveDropdown(activeDropdown === taskId ? null : taskId);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Completed':
        return <CheckCircle className="text-emerald-500" size={18} />;
      case 'In Progress':
        return <Clock className="text-amber-500" size={18} />;
      default:
        return <Circle className="text-gray-400" size={18} />;
    }
  };

  const getStatusClasses = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-emerald-100 text-emerald-800';
      case 'In Progress':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredTasks = state.tasks.filter((task) => {
    if (filter === 'all') return true;
    return task.status === filter;
  });

  return (
    <div className="mt-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex space-x-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-md text-sm ${
              filter === 'all'
                ? 'bg-indigo-100 text-indigo-800 font-medium'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('To Do')}
            className={`px-3 py-1 rounded-md text-sm ${
              filter === 'To Do'
                ? 'bg-indigo-100 text-indigo-800 font-medium'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            To Do
          </button>
          <button
            onClick={() => setFilter('In Progress')}
            className={`px-3 py-1 rounded-md text-sm ${
              filter === 'In Progress'
                ? 'bg-indigo-100 text-indigo-800 font-medium'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            In Progress
          </button>
          <button
            onClick={() => setFilter('Completed')}
            className={`px-3 py-1 rounded-md text-sm ${
              filter === 'Completed'
                ? 'bg-indigo-100 text-indigo-800 font-medium'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Completed
          </button>
        </div>
        <Button variant="primary" size="sm" onClick={onAddTask}>
          Add Task
        </Button>
      </div>

      {state.loading ? (
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      ) : filteredTasks.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <p className="text-gray-500">No tasks found</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTasks.map((task) => (
            <div
              key={task._id}
              className="bg-white border border-gray-200 rounded-lg p-4 transition-all hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3 flex-1">
                  <button
                    onClick={() => {
                      const newStatus =
                        task.status === 'Completed'
                          ? 'To Do'
                          : task.status === 'To Do'
                          ? 'In Progress'
                          : 'Completed';
                      handleStatusChange(task._id, newStatus);
                    }}
                    className="mt-1"
                  >
                    {getStatusIcon(task.status)}
                  </button>
                  <div className="flex-1">
                    <div className="flex items-center">
                      <h3 className="font-medium text-gray-900">{task.title}</h3>
                      <span
                        className={`text-xs px-2 py-0.5 ml-3 rounded-full ${getStatusClasses(task.status)}`}
                      >
                        {task.status}
                      </span>
                    </div>
                    <p className="text-gray-600 text-sm mt-1">{task.description}</p>
                    <div className="mt-2 text-xs text-gray-500">
                      {task.status === 'Completed' && task.completedAt ? (
                        <span>Completed on {format(new Date(task.completedAt), 'MMM d, yyyy')}</span>
                      ) : (
                        <span>Created on {format(new Date(task.createdAt), 'MMM d, yyyy')}</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="relative">
                  <button
                    onClick={() => toggleDropdown(task._id)}
                    className="p-1.5 text-gray-500 hover:text-gray-800 rounded-full hover:bg-gray-100"
                  >
                    <MoreVertical size={16} />
                  </button>
                  {activeDropdown === task._id && (
                    <div className="absolute right-0 mt-1 w-36 bg-white rounded-md shadow-lg z-10">
                      <button
                        onClick={() => {
                          onEditTask(task);
                          setActiveDropdown(null);
                        }}
                        className="flex items-center w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-t-md"
                      >
                        <Edit size={14} className="mr-2" /> Edit
                      </button>
                      <button
                        onClick={() => handleDeleteTask(task._id)}
                        className="flex items-center w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-b-md"
                      >
                        <Trash2 size={14} className="mr-2" /> Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TaskList;