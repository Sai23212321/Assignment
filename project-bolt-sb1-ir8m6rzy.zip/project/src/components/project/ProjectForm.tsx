import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProject } from '../../context/ProjectContext';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Alert from '../ui/Alert';

interface ProjectFormProps {
  isEditing?: boolean;
  initialData?: {
    _id: string;
    title: string;
    description: string;
  };
}

const ProjectForm: React.FC<ProjectFormProps> = ({ isEditing = false, initialData }) => {
  const [title, setTitle] = useState(initialData?.title || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [formErrors, setFormErrors] = useState({
    title: '',
    description: '',
  });

  const { createProject, updateProject, state } = useProject();
  const navigate = useNavigate();

  const validateForm = () => {
    let valid = true;
    const errors = {
      title: '',
      description: '',
    };

    if (!title.trim()) {
      errors.title = 'Title is required';
      valid = false;
    } else if (title.length > 100) {
      errors.title = 'Title must be less than 100 characters';
      valid = false;
    }

    if (!description.trim()) {
      errors.description = 'Description is required';
      valid = false;
    }

    setFormErrors(errors);
    return valid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      if (isEditing && initialData) {
        await updateProject(initialData._id, title, description);
      } else {
        await createProject(title, description);
      }
      navigate('/projects');
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-lg mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">
        {isEditing ? 'Edit Project' : 'Create New Project'}
      </h2>

      {state.error && (
        <Alert 
          type="error" 
          message={state.error} 
          onClose={() => {}} 
        />
      )}

      <Input
        label="Project Title"
        id="title"
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Enter project title"
        error={formErrors.title}
        fullWidth
      />

      <div className="mb-4">
        <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
          Project Description
        </label>
        <textarea
          id="description"
          rows={4}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Describe your project"
          className={`w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 ${
            formErrors.description ? 'border-red-500' : 'border-gray-300'
          }`}
        />
        {formErrors.description && (
          <p className="mt-1 text-sm text-red-600">{formErrors.description}</p>
        )}
      </div>

      <div className="flex justify-end space-x-4 mt-6">
        <Button
          type="button"
          variant="secondary"
          onClick={() => navigate('/projects')}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          variant="primary"
          disabled={state.loading}
        >
          {state.loading ? 'Saving...' : isEditing ? 'Update Project' : 'Create Project'}
        </Button>
      </div>
    </form>
  );
};

export default ProjectForm;