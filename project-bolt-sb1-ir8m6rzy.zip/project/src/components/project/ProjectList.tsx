import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Folder, MoreVertical, Edit, Trash2 } from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import Card from '../ui/Card';
import Button from '../ui/Button';
import { format } from 'date-fns';

const ProjectList: React.FC = () => {
  const { state, getProjects, deleteProject } = useProject();
  const [showDropdown, setShowDropdown] = React.useState<string | null>(null);

  useEffect(() => {
    getProjects();
  }, []);

  const toggleDropdown = (projectId: string) => {
    if (showDropdown === projectId) {
      setShowDropdown(null);
    } else {
      setShowDropdown(projectId);
    }
  };

  const handleDeleteProject = async (projectId: string) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      await deleteProject(projectId);
    }
    setShowDropdown(null);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Your Projects</h2>
        {state.projects.length < 4 && (
          <Link to="/projects/new">
            <Button variant="primary" size="sm" className="flex items-center">
              <Plus size={18} className="mr-1" /> Add Project
            </Button>
          </Link>
        )}
      </div>

      {state.loading ? (
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      ) : state.projects.length === 0 ? (
        <Card className="text-center py-12">
          <div className="flex flex-col items-center">
            <Folder size={64} className="text-gray-400 mb-3" />
            <h3 className="text-xl font-semibold mb-2">No projects yet</h3>
            <p className="text-gray-600 mb-6">Get started by creating your first project</p>
            <Link to="/projects/new">
              <Button variant="primary" size="md" className="flex items-center">
                <Plus size={18} className="mr-2" /> Create Project
              </Button>
            </Link>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {state.projects.map((project) => (
            <Card key={project._id} className="transform transition-transform hover:scale-105">
              <div className="relative">
                <div className="absolute top-0 right-0">
                  <button
                    onClick={() => toggleDropdown(project._id)}
                    className="p-2 text-gray-500 hover:text-gray-800 rounded-full hover:bg-gray-100"
                  >
                    <MoreVertical size={18} />
                  </button>
                  {showDropdown === project._id && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10">
                      <Link
                        to={`/projects/edit/${project._id}`}
                        className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-t-md"
                      >
                        <Edit size={16} className="mr-2" /> Edit Project
                      </Link>
                      <button
                        onClick={() => handleDeleteProject(project._id)}
                        className="flex items-center w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-b-md"
                      >
                        <Trash2 size={16} className="mr-2" /> Delete Project
                      </button>
                    </div>
                  )}
                </div>
              </div>
              <Link to={`/projects/${project._id}`}>
                <div className="pt-4">
                  <h3 className="text-lg font-semibold mb-2 text-indigo-700 truncate">{project.title}</h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{project.description}</p>
                  <div className="text-xs text-gray-500">
                    Created: {format(new Date(project.createdAt), 'MMM d, yyyy')}
                  </div>
                </div>
              </Link>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProjectList;