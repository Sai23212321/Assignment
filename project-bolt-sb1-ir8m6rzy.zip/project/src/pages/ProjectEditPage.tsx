import React, { useEffect } from 'react';
import { useParams, Navigate, useNavigate } from 'react-router-dom';
import Header from '../components/layout/Header';
import ProjectForm from '../components/project/ProjectForm';
import { useAuth } from '../context/AuthContext';
import { useProject } from '../context/ProjectContext';

const ProjectEditPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { state: authState } = useAuth();
  const { state: projectState, getProjectById } = useProject();
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      getProjectById(id);
    }
  }, [id]);

  if (!authState.user) {
    return <Navigate to="/login" />;
  }

  if (projectState.loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header />
        <main className="flex-1 flex justify-center items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </main>
      </div>
    );
  }

  if (!projectState.currentProject && !projectState.loading) {
    navigate('/projects');
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <ProjectForm isEditing={true} initialData={projectState.currentProject || undefined} />
      </main>
    </div>
  );
};

export default ProjectEditPage;