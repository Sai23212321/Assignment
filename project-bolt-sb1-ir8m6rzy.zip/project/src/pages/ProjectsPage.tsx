import React from 'react';
import Header from '../components/layout/Header';
import ProjectList from '../components/project/ProjectList';
import { useAuth } from '../context/AuthContext';
import { Navigate } from 'react-router-dom';

const ProjectsPage: React.FC = () => {
  const { state } = useAuth();

  if (!state.user) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <ProjectList />
      </main>
    </div>
  );
};

export default ProjectsPage;