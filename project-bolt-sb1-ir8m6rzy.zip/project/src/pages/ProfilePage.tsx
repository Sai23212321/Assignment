import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { User } from 'lucide-react';
import Header from '../components/layout/Header';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import Alert from '../components/ui/Alert';
import { useAuth } from '../context/AuthContext';

const ProfilePage: React.FC = () => {
  const { state, updateProfile } = useAuth();
  const [formData, setFormData] = useState({
    name: state.user?.name || '',
    email: state.user?.email || '',
    country: state.user?.country || '',
    password: '',
    confirmPassword: '',
  });

  const [formErrors, setFormErrors] = useState({
    name: '',
    email: '',
    country: '',
    password: '',
    confirmPassword: '',
  });

  const [updateSuccess, setUpdateSuccess] = useState(false);

  if (!state.user) {
    return <Navigate to="/login" />;
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    
    // Clear error when user types
    setFormErrors({
      ...formErrors,
      [name]: '',
    });
    
    setUpdateSuccess(false);
  };

  const validateForm = () => {
    const errors = {
      name: '',
      email: '',
      country: '',
      password: '',
      confirmPassword: '',
    };
    let isValid = true;

    if (!formData.name) {
      errors.name = 'Name is required';
      isValid = false;
    }

    if (!formData.email) {
      errors.email = 'Email is required';
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Email is invalid';
      isValid = false;
    }

    if (!formData.country) {
      errors.country = 'Country is required';
      isValid = false;
    }

    if (formData.password && formData.password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
      isValid = false;
    }

    if (formData.password && formData.password !== formData.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
      isValid = false;
    }

    setFormErrors(errors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      const userData = {
        name: formData.name,
        email: formData.email,
        country: formData.country,
      };

      if (formData.password) {
        Object.assign(userData, { password: formData.password });
      }

      await updateProfile(userData);
      setUpdateSuccess(true);
      
      // Clear password fields after successful update
      setFormData({
        ...formData,
        password: '',
        confirmPassword: '',
      });
    } catch (error) {
      console.error('Form submission error:', error);
      setUpdateSuccess(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-8">
          <div className="flex items-center mb-6">
            <div className="bg-indigo-100 p-3 rounded-full mr-4">
              <User size={24} className="text-indigo-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">Your Profile</h1>
          </div>

          {state.error && (
            <Alert 
              type="error" 
              message={state.error} 
              onClose={() => {}} 
            />
          )}
          
          {updateSuccess && (
            <Alert 
              type="success" 
              message="Profile updated successfully" 
              onClose={() => setUpdateSuccess(false)} 
            />
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Name"
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              error={formErrors.name}
              fullWidth
            />

            <Input
              label="Email Address"
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              error={formErrors.email}
              fullWidth
            />

            <Input
              label="Country"
              id="country"
              name="country"
              type="text"
              value={formData.country}
              onChange={handleChange}
              error={formErrors.country}
              fullWidth
            />

            <hr className="my-6" />
            
            <div className="mb-2">
              <h3 className="text-lg font-semibold">Change Password</h3>
              <p className="text-gray-600 text-sm">Leave blank to keep current password</p>
            </div>

            <Input
              label="New Password"
              id="password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Enter new password"
              error={formErrors.password}
              fullWidth
            />

            <Input
              label="Confirm New Password"
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              value={formData.confirmPassword}
              onChange={handleChange}
              placeholder="Confirm new password"
              error={formErrors.confirmPassword}
              fullWidth
            />

            <div className="flex justify-end pt-4">
              <Button
                type="submit"
                variant="primary"
                disabled={state.loading}
              >
                {state.loading ? 'Updating...' : 'Update Profile'}
              </Button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
};

export default ProfilePage;