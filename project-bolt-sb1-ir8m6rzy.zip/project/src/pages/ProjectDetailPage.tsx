import React, { useEffect, useState } from 'react';
import { useParams, Navigate, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit } from 'lucide-react';
import Header from '../components/layout/Header';
import TaskList from '../components/task/TaskList';
import TaskForm from '../components/task/TaskForm';
import Button from '../components/ui/Button';
import { useAuth } from '../context/AuthContext';
import { useProject } from '../context/ProjectContext';
import { useTask } from '../context/TaskContext';
import { Task } from '../types';

const ProjectDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { state: authState } = useAuth();
  const { state: projectState, getProjectById } = useProject();
  const { getTasksByProject } = useTask();
  const navigate = useNavigate();
  
  const [isTaskFormOpen, setIsTaskFormOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState<Task | undefined>(undefined);

  useEffect(() => {
    if (id) {
      getProjectById(id);
      getTasksByProject(id);
    }
  }, [id]);

  if (!authState.user) {
    return <Navigate to="/login" />;
  }

  const handleAddTask = () => {
    setCurrentTask(undefined);
    setIsTaskFormOpen(true);
  };

  const handleEditTask = (task: Task) => {
    setCurrentTask(task);
    setIsTaskFormOpen(true);
  };

  const handleCloseTaskForm = () => {
    setIsTaskFormOpen(false);
    if (id) {
      getTasksByProject(id);
    }
  };

  if (projectState.loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header />
        <main className="flex-1 flex justify-center items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </main>
      </div>
    );
  }

  if (!projectState.currentProject && !projectState.loading) {
    navigate('/projects');
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link to="/projects" className="inline-flex items-center text-indigo-600 hover:text-indigo-800 mb-4">
            <ArrowLeft size={16} className="mr-1" /> Back to Projects
          </Link>
          
          <div className="flex flex-col md:flex-row justify-between md:items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-800 mb-1">
                {projectState.currentProject?.title}
              </h1>
              <p className="text-gray-600">{projectState.currentProject?.description}</p>
            </div>
            
            <Link to={`/projects/edit/${id}`} className="mt-4 md:mt-0">
              <Button variant="secondary" size="sm" className="flex items-center">
                <Edit size={16} className="mr-1" /> Edit Project
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <TaskList 
            projectId={id || ''} 
            onAddTask={handleAddTask} 
            onEditTask={handleEditTask}
          />
        </div>
        
        <TaskForm 
          isOpen={isTaskFormOpen} 
          onClose={handleCloseTaskForm} 
          projectId={id || ''} 
          task={currentTask}
        />
      </main>
    </div>
  );
};

export default ProjectDetailPage;