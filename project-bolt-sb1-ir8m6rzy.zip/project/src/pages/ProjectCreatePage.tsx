import React from 'react';
import { Navigate } from 'react-router-dom';
import Header from '../components/layout/Header';
import ProjectForm from '../components/project/ProjectForm';
import { useAuth } from '../context/AuthContext';

const ProjectCreatePage: React.FC = () => {
  const { state } = useAuth();

  if (!state.user) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <ProjectForm />
      </main>
    </div>
  );
};

export default ProjectCreatePage;