import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ClipboardList, Clock, Target } from 'lucide-react';
import Header from '../components/layout/Header';
import Button from '../components/ui/Button';
import { useAuth } from '../context/AuthContext';

const HomePage: React.FC = () => {
  const { state: authState } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-indigo-600 to-indigo-800 text-white py-20 px-4">
          <div className="container mx-auto max-w-5xl">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-10 md:mb-0">
                <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
                  Keep track of your projects with ease
                </h1>
                <p className="text-xl text-indigo-100 mb-8">
                  Organize your tasks, monitor progress, and achieve your goals with our intuitive task tracking platform.
                </p>
                {authState.user ? (
                  <Link to="/dashboard">
                    <Button
                      variant="primary"
                      size="lg"
                      className="bg-white text-indigo-700 hover:bg-indigo-50"
                    >
                      Go to Dashboard
                    </Button>
                  </Link>
                ) : (
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Link to="/register">
                      <Button
                        variant="primary"
                        size="lg"
                        className="bg-white text-indigo-700 hover:bg-indigo-50"
                      >
                        Get Started
                      </Button>
                    </Link>
                    <Link to="/login">
                      <Button
                        variant="secondary"
                        size="lg"
                        className="bg-transparent border border-white text-white hover:bg-white hover:bg-opacity-10"
                      >
                        Log In
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
              <div className="md:w-1/2 md:pl-10">
                <div className="bg-white bg-opacity-10 p-6 rounded-lg backdrop-blur-sm border border-white border-opacity-20 shadow-xl">
                  <div className="space-y-4">
                    {[1, 2, 3].map((item) => (
                      <div key={item} className="flex items-center">
                        <div className="w-8 h-8 bg-indigo-500 bg-opacity-30 rounded-full flex items-center justify-center mr-4">
                          <CheckCircle size={16} className="text-white" />
                        </div>
                        <div className="h-4 bg-white bg-opacity-30 rounded-full w-full"></div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 px-4 bg-gray-50">
          <div className="container mx-auto max-w-5xl">
            <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">
              Features that make task management simple
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 transform transition-transform hover:scale-105">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <ClipboardList size={24} className="text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Project Management</h3>
                <p className="text-gray-600">
                  Create up to 4 projects to organize your work and keep your tasks properly categorized.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 transform transition-transform hover:scale-105">
                <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                  <Target size={24} className="text-emerald-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Task Tracking</h3>
                <p className="text-gray-600">
                  Track task progress from To Do, through In Progress, to Completed with a simple interface.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 transform transition-transform hover:scale-105">
                <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-4">
                  <Clock size={24} className="text-amber-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Time Tracking</h3>
                <p className="text-gray-600">
                  Monitor when tasks are created and completed to stay on top of your timeline.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 px-4 bg-indigo-50">
          <div className="container mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold mb-4 text-gray-800">Ready to get started?</h2>
            <p className="text-xl text-gray-600 mb-8">
              Join thousands of users who are already managing their tasks effectively.
            </p>
            {!authState.user && (
              <Link to="/register">
                <Button variant="primary" size="lg">
                  Sign Up for Free
                </Button>
              </Link>
            )}
          </div>
        </section>
      </main>
      
      <footer className="bg-gray-800 text-white py-8 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-xl font-bold mb-4 md:mb-0">TaskTracker</div>
            <div className="text-sm text-gray-400">
              &copy; {new Date().getFullYear()} TaskTracker. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;