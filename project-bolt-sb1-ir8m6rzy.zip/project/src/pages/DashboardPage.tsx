import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layers, CheckCircle, Clock, List, User } from 'lucide-react';
import Header from '../components/layout/Header';
import StatCard from '../components/dashboard/StatCard';
import { useAuth } from '../context/AuthContext';
import { useProject } from '../context/ProjectContext';
import { useTask } from '../context/TaskContext';

const DashboardPage: React.FC = () => {
  const { state: authState } = useAuth();
  const { state: projectState, getProjects } = useProject();
  const { state: taskState } = useTask();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authState.user) {
      navigate('/login');
      return;
    }

    getProjects();
  }, [authState.user, navigate]);

  const getTotalTasks = () => {
    let total = 0;
    projectState.projects.forEach((project) => {
      const projectTasks = taskState.tasks.filter((task) => task.project === project._id);
      total += projectTasks.length;
    });
    return total;
  };

  const getCompletedTasks = () => {
    return taskState.tasks.filter((task) => task.status === 'Completed').length;
  };

  const getInProgressTasks = () => {
    return taskState.tasks.filter((task) => task.status === 'In Progress').length;
  };

  const getPendingTasks = () => {
    return taskState.tasks.filter((task) => task.status === 'To Do').length;
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        </div>

        {/* Welcome Message */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8 border border-gray-200">
          <div className="flex items-center">
            <div className="bg-indigo-100 p-3 rounded-full mr-4">
              <User size={24} className="text-indigo-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold">Welcome back, {authState.user?.name}</h2>
              <p className="text-gray-600">Here's an overview of your tasks and projects</p>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Projects"
            value={projectState.projects.length}
            icon={<Layers size={24} />}
            color="indigo"
          />
          <StatCard
            title="Completed Tasks"
            value={getCompletedTasks()}
            icon={<CheckCircle size={24} />}
            color="emerald"
          />
          <StatCard
            title="In Progress"
            value={getInProgressTasks()}
            icon={<Clock size={24} />}
            color="amber"
          />
          <StatCard
            title="To Do"
            value={getPendingTasks()}
            icon={<List size={24} />}
            color="red"
          />
        </div>

        {/* Recent Projects */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8 border border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Recent Projects</h2>
          {projectState.loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          ) : projectState.projects.length === 0 ? (
            <p className="text-gray-500 py-4">No projects yet. Create your first project to get started.</p>
          ) : (
            <div className="divide-y divide-gray-200">
              {projectState.projects.slice(0, 3).map((project) => (
                <div key={project._id} className="py-3">
                  <div className="flex justify-between items-center">
                    <h3 className="font-medium">{project.title}</h3>
                    <button
                      onClick={() => navigate(`/projects/${project._id}`)}
                      className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                    >
                      View Details
                    </button>
                  </div>
                  <p className="text-gray-600 text-sm mt-1 line-clamp-1">{project.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default DashboardPage;