import React, { createContext, useContext, useReducer } from 'react';
import axios from 'axios';
import { Task, TaskState } from '../types';

interface TaskContextType {
  state: TaskState;
  getTasksByProject: (projectId: string) => Promise<void>;
  getTaskById: (id: string) => Promise<void>;
  createTask: (title: string, description: string, status: string, projectId: string) => Promise<void>;
  updateTask: (id: string, title: string, description: string, status: string) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
  clearTask: () => void;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

type TaskAction =
  | { type: 'GET_TASKS_REQUEST' }
  | { type: 'GET_TASKS_SUCCESS'; payload: Task[] }
  | { type: 'GET_TASKS_FAIL'; payload: string }
  | { type: 'GET_TASK_REQUEST' }
  | { type: 'GET_TASK_SUCCESS'; payload: Task }
  | { type: 'GET_TASK_FAIL'; payload: string }
  | { type: 'CREATE_TASK_REQUEST' }
  | { type: 'CREATE_TASK_SUCCESS'; payload: Task }
  | { type: 'CREATE_TASK_FAIL'; payload: string }
  | { type: 'UPDATE_TASK_REQUEST' }
  | { type: 'UPDATE_TASK_SUCCESS'; payload: Task }
  | { type: 'UPDATE_TASK_FAIL'; payload: string }
  | { type: 'DELETE_TASK_REQUEST' }
  | { type: 'DELETE_TASK_SUCCESS'; payload: string }
  | { type: 'DELETE_TASK_FAIL'; payload: string }
  | { type: 'CLEAR_TASK' }
  | { type: 'CLEAR_ERROR' };

const initialState: TaskState = {
  tasks: [],
  currentTask: null,
  loading: false,
  error: null,
};

const taskReducer = (state: TaskState, action: TaskAction): TaskState => {
  switch (action.type) {
    case 'GET_TASKS_REQUEST':
    case 'GET_TASK_REQUEST':
    case 'CREATE_TASK_REQUEST':
    case 'UPDATE_TASK_REQUEST':
    case 'DELETE_TASK_REQUEST':
      return { ...state, loading: true, error: null };
    case 'GET_TASKS_SUCCESS':
      return { ...state, loading: false, tasks: action.payload, error: null };
    case 'GET_TASK_SUCCESS':
      return { ...state, loading: false, currentTask: action.payload, error: null };
    case 'CREATE_TASK_SUCCESS':
      return {
        ...state,
        loading: false,
        tasks: [...state.tasks, action.payload],
        error: null,
      };
    case 'UPDATE_TASK_SUCCESS':
      return {
        ...state,
        loading: false,
        tasks: state.tasks.map((task) =>
          task._id === action.payload._id ? action.payload : task
        ),
        currentTask: action.payload,
        error: null,
      };
    case 'DELETE_TASK_SUCCESS':
      return {
        ...state,
        loading: false,
        tasks: state.tasks.filter((task) => task._id !== action.payload),
        currentTask: null,
        error: null,
      };
    case 'GET_TASKS_FAIL':
    case 'GET_TASK_FAIL':
    case 'CREATE_TASK_FAIL':
    case 'UPDATE_TASK_FAIL':
    case 'DELETE_TASK_FAIL':
      return { ...state, loading: false, error: action.payload };
    case 'CLEAR_TASK':
      return { ...state, currentTask: null };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    default:
      return state;
  }
};

export const TaskProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(taskReducer, initialState);

  // Get tasks by project
  const getTasksByProject = async (projectId: string) => {
    try {
      dispatch({ type: 'GET_TASKS_REQUEST' });
      const { data } = await axios.get(`/api/tasks/project/${projectId}`);
      dispatch({ type: 'GET_TASKS_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'GET_TASKS_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Get task by ID
  const getTaskById = async (id: string) => {
    try {
      dispatch({ type: 'GET_TASK_REQUEST' });
      const { data } = await axios.get(`/api/tasks/${id}`);
      dispatch({ type: 'GET_TASK_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'GET_TASK_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Create task
  const createTask = async (title: string, description: string, status: string, projectId: string) => {
    try {
      dispatch({ type: 'CREATE_TASK_REQUEST' });
      const { data } = await axios.post('/api/tasks', {
        title,
        description,
        status,
        projectId,
      });
      dispatch({ type: 'CREATE_TASK_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'CREATE_TASK_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Update task
  const updateTask = async (id: string, title: string, description: string, status: string) => {
    try {
      dispatch({ type: 'UPDATE_TASK_REQUEST' });
      const { data } = await axios.put(`/api/tasks/${id}`, {
        title,
        description,
        status,
      });
      dispatch({ type: 'UPDATE_TASK_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'UPDATE_TASK_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Delete task
  const deleteTask = async (id: string) => {
    try {
      dispatch({ type: 'DELETE_TASK_REQUEST' });
      await axios.delete(`/api/tasks/${id}`);
      dispatch({ type: 'DELETE_TASK_SUCCESS', payload: id });
    } catch (error: any) {
      dispatch({
        type: 'DELETE_TASK_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Clear current task
  const clearTask = () => {
    dispatch({ type: 'CLEAR_TASK' });
  };

  return (
    <TaskContext.Provider
      value={{
        state,
        getTasksByProject,
        getTaskById,
        createTask,
        updateTask,
        deleteTask,
        clearTask,
      }}
    >
      {children}
    </TaskContext.Provider>
  );
};

export const useTask = (): TaskContextType => {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTask must be used within a TaskProvider');
  }
  return context;
};