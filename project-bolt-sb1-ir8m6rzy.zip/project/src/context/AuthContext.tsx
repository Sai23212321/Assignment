import React, { createContext, useContext, useReducer, useEffect } from 'react';
import axios from 'axios';
import { User, AuthState } from '../types';

interface AuthContextType {
  state: AuthState;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, country: string) => Promise<void>;
  logout: () => void;
  updateProfile: (userData: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

type AuthAction =
  | { type: 'LOGIN_REQUEST' }
  | { type: 'LOGIN_SUCCESS'; payload: User }
  | { type: 'LOGIN_FAIL'; payload: string }
  | { type: 'REGISTER_REQUEST' }
  | { type: 'REGISTER_SUCCESS'; payload: User }
  | { type: 'REGISTER_FAIL'; payload: string }
  | { type: 'LOGOUT' }
  | { type: 'UPDATE_PROFILE_REQUEST' }
  | { type: 'UPDATE_PROFILE_SUCCESS'; payload: User }
  | { type: 'UPDATE_PROFILE_FAIL'; payload: string }
  | { type: 'CLEAR_ERROR' };

const initialState: AuthState = {
  user: localStorage.getItem('user')
    ? JSON.parse(localStorage.getItem('user') || '{}')
    : null,
  loading: false,
  error: null,
};

const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'LOGIN_REQUEST':
    case 'REGISTER_REQUEST':
    case 'UPDATE_PROFILE_REQUEST':
      return { ...state, loading: true, error: null };
    case 'LOGIN_SUCCESS':
    case 'REGISTER_SUCCESS':
    case 'UPDATE_PROFILE_SUCCESS':
      localStorage.setItem('user', JSON.stringify(action.payload));
      return { ...state, loading: false, user: action.payload, error: null };
    case 'LOGIN_FAIL':
    case 'REGISTER_FAIL':
    case 'UPDATE_PROFILE_FAIL':
      return { ...state, loading: false, error: action.payload };
    case 'LOGOUT':
      localStorage.removeItem('user');
      return { ...state, user: null };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    default:
      return state;
  }
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // Axios default config
  useEffect(() => {
    if (state.user?.token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${state.user.token}`;
    } else {
      delete axios.defaults.headers.common['Authorization'];
    }
  }, [state.user]);

  // Login function
  const login = async (email: string, password: string) => {
    try {
      dispatch({ type: 'LOGIN_REQUEST' });
      const { data } = await axios.post('/api/users/login', { email, password });
      dispatch({ type: 'LOGIN_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'LOGIN_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Register function
  const register = async (name: string, email: string, password: string, country: string) => {
    try {
      dispatch({ type: 'REGISTER_REQUEST' });
      const { data } = await axios.post('/api/users', { name, email, password, country });
      dispatch({ type: 'REGISTER_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'REGISTER_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Logout function
  const logout = () => {
    dispatch({ type: 'LOGOUT' });
  };

  // Update profile
  const updateProfile = async (userData: Partial<User>) => {
    try {
      dispatch({ type: 'UPDATE_PROFILE_REQUEST' });
      const { data } = await axios.put('/api/users/profile', userData);
      dispatch({ type: 'UPDATE_PROFILE_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'UPDATE_PROFILE_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        state,
        login,
        register,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};