import React, { createContext, useContext, useReducer } from 'react';
import axios from 'axios';
import { Project, ProjectState } from '../types';
import { useAuth } from './AuthContext';

interface ProjectContextType {
  state: ProjectState;
  getProjects: () => Promise<void>;
  getProjectById: (id: string) => Promise<void>;
  createProject: (title: string, description: string) => Promise<void>;
  updateProject: (id: string, title: string, description: string) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  clearProject: () => void;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

type ProjectAction =
  | { type: 'GET_PROJECTS_REQUEST' }
  | { type: 'GET_PROJECTS_SUCCESS'; payload: Project[] }
  | { type: 'GET_PROJECTS_FAIL'; payload: string }
  | { type: 'GET_PROJECT_REQUEST' }
  | { type: 'GET_PROJECT_SUCCESS'; payload: Project }
  | { type: 'GET_PROJECT_FAIL'; payload: string }
  | { type: 'CREATE_PROJECT_REQUEST' }
  | { type: 'CREATE_PROJECT_SUCCESS'; payload: Project }
  | { type: 'CREATE_PROJECT_FAIL'; payload: string }
  | { type: 'UPDATE_PROJECT_REQUEST' }
  | { type: 'UPDATE_PROJECT_SUCCESS'; payload: Project }
  | { type: 'UPDATE_PROJECT_FAIL'; payload: string }
  | { type: 'DELETE_PROJECT_REQUEST' }
  | { type: 'DELETE_PROJECT_SUCCESS'; payload: string }
  | { type: 'DELETE_PROJECT_FAIL'; payload: string }
  | { type: 'CLEAR_PROJECT' }
  | { type: 'CLEAR_ERROR' };

const initialState: ProjectState = {
  projects: [],
  currentProject: null,
  loading: false,
  error: null,
};

const projectReducer = (state: ProjectState, action: ProjectAction): ProjectState => {
  switch (action.type) {
    case 'GET_PROJECTS_REQUEST':
    case 'GET_PROJECT_REQUEST':
    case 'CREATE_PROJECT_REQUEST':
    case 'UPDATE_PROJECT_REQUEST':
    case 'DELETE_PROJECT_REQUEST':
      return { ...state, loading: true, error: null };
    case 'GET_PROJECTS_SUCCESS':
      return { ...state, loading: false, projects: action.payload, error: null };
    case 'GET_PROJECT_SUCCESS':
      return { ...state, loading: false, currentProject: action.payload, error: null };
    case 'CREATE_PROJECT_SUCCESS':
      return {
        ...state,
        loading: false,
        projects: [...state.projects, action.payload],
        error: null,
      };
    case 'UPDATE_PROJECT_SUCCESS':
      return {
        ...state,
        loading: false,
        projects: state.projects.map((project) =>
          project._id === action.payload._id ? action.payload : project
        ),
        currentProject: action.payload,
        error: null,
      };
    case 'DELETE_PROJECT_SUCCESS':
      return {
        ...state,
        loading: false,
        projects: state.projects.filter((project) => project._id !== action.payload),
        currentProject: null,
        error: null,
      };
    case 'GET_PROJECTS_FAIL':
    case 'GET_PROJECT_FAIL':
    case 'CREATE_PROJECT_FAIL':
    case 'UPDATE_PROJECT_FAIL':
    case 'DELETE_PROJECT_FAIL':
      return { ...state, loading: false, error: action.payload };
    case 'CLEAR_PROJECT':
      return { ...state, currentProject: null };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    default:
      return state;
  }
};

export const ProjectProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(projectReducer, initialState);
  const { state: authState } = useAuth();

  // Get all projects
  const getProjects = async () => {
    try {
      dispatch({ type: 'GET_PROJECTS_REQUEST' });
      const { data } = await axios.get('/api/projects');
      dispatch({ type: 'GET_PROJECTS_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'GET_PROJECTS_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Get project by ID
  const getProjectById = async (id: string) => {
    try {
      dispatch({ type: 'GET_PROJECT_REQUEST' });
      const { data } = await axios.get(`/api/projects/${id}`);
      dispatch({ type: 'GET_PROJECT_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'GET_PROJECT_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Create project
  const createProject = async (title: string, description: string) => {
    try {
      dispatch({ type: 'CREATE_PROJECT_REQUEST' });
      const { data } = await axios.post('/api/projects', { title, description });
      dispatch({ type: 'CREATE_PROJECT_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'CREATE_PROJECT_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Update project
  const updateProject = async (id: string, title: string, description: string) => {
    try {
      dispatch({ type: 'UPDATE_PROJECT_REQUEST' });
      const { data } = await axios.put(`/api/projects/${id}`, { title, description });
      dispatch({ type: 'UPDATE_PROJECT_SUCCESS', payload: data });
    } catch (error: any) {
      dispatch({
        type: 'UPDATE_PROJECT_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Delete project
  const deleteProject = async (id: string) => {
    try {
      dispatch({ type: 'DELETE_PROJECT_REQUEST' });
      await axios.delete(`/api/projects/${id}`);
      dispatch({ type: 'DELETE_PROJECT_SUCCESS', payload: id });
    } catch (error: any) {
      dispatch({
        type: 'DELETE_PROJECT_FAIL',
        payload: error.response?.data?.message || 'An error occurred',
      });
    }
  };

  // Clear current project
  const clearProject = () => {
    dispatch({ type: 'CLEAR_PROJECT' });
  };

  return (
    <ProjectContext.Provider
      value={{
        state,
        getProjects,
        getProjectById,
        createProject,
        updateProject,
        deleteProject,
        clearProject,
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
};

export const useProject = (): ProjectContextType => {
  const context = useContext(ProjectContext);
  if (context === undefined) {
    throw new Error('useProject must be used within a ProjectProvider');
  }
  return context;
};